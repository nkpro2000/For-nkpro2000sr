class WaveIOError(Exception): pass

class WaveMissingCallStrategy(Exception): pass
