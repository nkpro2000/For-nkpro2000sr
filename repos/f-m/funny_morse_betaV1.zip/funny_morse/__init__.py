#!/usr/bin/env python3

__title__ = "funny-morse"
__author__ = "Naveen S R"
__license__ = "MIT"
__copyright__ = "Copyright 2020 Naveen S R"

import os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import morse
import play, show, key, esp32
from parallel import Parallel

sys.path.pop(0)

code = morse.stringToMorse


def audio(message, wpm=-1, fs=-1, sps=-1, freq=-1):
    """ To play morse code audio signal for message
    Args:
        message: Message to convert
        wpm: Words per minute
        fs: Farnsworth speed
        sps: Samples per second
        freq: Frequency of audio signal
    """
    wpm = morse.WPM if wpm == -1 else wpm
    fs = morse.FS if fs == -1 else fs
    play.main(message, wpm, fs, sps, freq)


def audio_file(filename, message, wpm=-1, fs=-1, sps=-1, freq=-1):
    """ To save morse code audio file for message
    Args:
        filename: filepath for audio output file
        message: Message to convert
        wpm: Words per minute
        fs: Farnsworth speed
        sps: Samples per second
        freq: Frequency of audio signal
    """
    wpm = morse.WPM if wpm == -1 else wpm
    fs = morse.FS if fs == -1 else fs
    play.main(message, wpm, fs, sps, freq, out_file=filename)


def window(message, wpm=-1, fs=-1, fps=-1):
    """ To show morse code signal in a window for message
    Args:
        message: Message to convert
        wpm: Words per minute
        fs: Farnsworth speed
        fps: Frames per second
    """
    wpm = morse.WPM if wpm == -1 else wpm
    fs = morse.FS if fs == -1 else fs
    show.main(message, wpm, fs, fps)


def caps_lock(message, wpm=-1, fs=-1, ksps=-1):
    """ To show message as morse code by blinking caps lock indicator
    Args:
        message: Message to convert
        wpm: Words per minute
        fs: Farnsworth speed
        ksps: Key strokes per second
    """
    wpm = morse.WPM if wpm == -1 else wpm
    fs = morse.FS if fs == -1 else fs
    key.main(message, wpm, fs, ksps, key="caps")


def num_lock(message, wpm=-1, fs=-1, ksps=-1):
    """ To show message as morse code by blinking num lock indicator
    Args:
        message: Message to convert
        wpm: Words per minute
        fs: Farnsworth speed
        ksps: Key strokes per second
    """
    wpm = morse.WPM if wpm == -1 else wpm
    fs = morse.FS if fs == -1 else fs
    key.main(message, wpm, fs, ksps, key="num")


def scroll_lock(message, wpm=-1, fs=-1, ksps=-1):
    """ To show message as morse code by blinking scroll lock indicator
    Args:
        message: Message to convert
        wpm: Words per minute
        fs: Farnsworth speed
        ksps: Key strokes per second
    """
    wpm = morse.WPM if wpm == -1 else wpm
    fs = morse.FS if fs == -1 else fs
    key.main(message, wpm, fs, ksps, key="scroll")
