#!/usr/bin/env python3

import time
from pynput import keyboard

import morse

KSPS = 1000  # KeyStrokes Per Second
WPM = morse.WPM
FS = morse.FS


def info(ksps=-1):
    ksps = KSPS if ksps == -1 else ksps
    print("Keyboard :")
    print(" Strokes per second =", ksps)


def main(message, wpm=-1, fs=-1, ksps=-1, key="caps"):
    wpm = WPM if wpm == -1 else wpm
    fs = FS if fs == -1 else fs
    ksps = KSPS if ksps == -1 else ksps
    code = morse.stringToMorse(message)
    bool_arr = morse.morseToBoolArr(code, ksps, wpm, fs)
    Control(bool_arr, key, ksps).loop()


class Control(keyboard.Controller):
    def __init__(self, bool_arr, key="caps", ksps=-1):
        self.ksps = KSPS if ksps == -1 else ksps
        self.sleep = 1 / 1000
        self.bool_arr = bool_arr
        self.len = len(bool_arr)
        self.time = time.time()
        if key == "num":
            self.key = keyboard.Key.num_lock
        elif key == "scroll":
            self.key = keyboard.Key.scroll_lock
        else:
            self.key = keyboard.Key.caps_lock
        self.current = False
        super().__init__()

    def lock(self):
        self.press(self.key)
        self.release(self.key)
        self.current = True

    def release_(self):
        self.press(self.key)
        self.release(self.key)
        self.current = False

    def loop(self):
        while 5:
            ms = time.time() - self.time
            i = int(ms * self.ksps)
            if i >= self.len:
                if self.current == True:
                    self.release_()
                break
            now = self.bool_arr[i]
            if self.current != now:
                if now == True:
                    self.lock()
                else:
                    self.release_()
            time.sleep(self.sleep)
