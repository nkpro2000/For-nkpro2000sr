#!/usr/bin/env python3

import time
import tkinter

import morse

FPS = 1000
WPM = morse.WPM
FS = morse.FS


def info(fps=-1):
    fps = FPS if fps == -1 else fps
    print("Window :")
    print(" frames per second  =", fps)


def main(message, wpm=-1, fs=-1, fps=-1):
    wpm = WPM if wpm == -1 else wpm
    fs = FS if fs == -1 else fs
    fps = FPS if fps == -1 else fps
    code = morse.stringToMorse(message)
    bool_arr = morse.morseToBoolArr(code, fps, wpm, fs)
    window = Window(bool_arr, fps)
    window.mainloop()


class Window(tkinter.Tk):
    def __init__(self, bool_arr, fps=-1):
        self.fps = FPS if fps == -1 else fps
        self.sleep = 1
        self.bool_arr = bool_arr
        self.len = len(bool_arr)
        self.time = time.time()
        self.current = False
        super().__init__()
        self.title("funny-morse")
        self.configure(bg="#000000")
        self.update()

    def white(self):
        self.configure(bg="#ffffff")
        self.current = True
        self.after(self.sleep, self.update)

    def black(self):
        self.configure(bg="#000000")
        self.current = False
        self.after(self.sleep, self.update)

    def update(self):
        ms = time.time() - self.time
        i = int(ms * self.fps)
        if i >= self.len:
            self.destroy()
            return
        now = self.bool_arr[i]
        if self.current != now:
            if now == True:
                self.white()
            else:
                self.black()
        else:
            self.after(self.sleep, self.update)
