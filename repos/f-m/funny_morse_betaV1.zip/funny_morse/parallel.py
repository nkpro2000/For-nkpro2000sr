#!/usr/bin/env python3

from threading import Thread
from functools import partial

import play, show, key, esp32


modesTable = {
    "play": play.main,
    "window": show.main,
    "capsL": partial(key.main, key="caps"),
    "numL": partial(key.main, key="num"),
    "scrollL": partial(key.main, key="scroll"),
}

modesTable["p"] = modesTable["play"]
modesTable["w"] = modesTable["window"]
modesTable["c"] = modesTable["capsL"]
modesTable["n"] = modesTable["numL"]
modesTable["s"] = modesTable["scrollL"]


class Parallel:
    """ To parallel modes """

    def __init__(self, message, wpm=-1, fs=-1, modes=(), **modes_):
        """
        Args:
            message: Message to convert
            wpm: Words per minute
            fs: Farnsworth speed
            modes (List[Union[str,Callable]]): list of modes or callable to call
            **modes_ (Mapping[str,Any]): mapping of modes to kwargs (for modes)
        """
        self.kwargs = {
            "message": message,
            "wpm": wpm,
            "fs": fs,
        }
        self.threads = []
        for mode in modes:
            if type(mode) is str:
                target = modesTable[mode]
            else:
                target = mode
            kwargs = dict()
            kwargs.update(self.kwargs)
            thread = Thread(target=target, kwargs=kwargs)
            self.threads.append(thread)
        for mode, kwargs_ in modes_.items():
            target = modesTable[mode]
            kwargs = dict()
            kwargs.update(self.kwargs)
            kwargs.update(kwargs_)
            thread = Thread(target=target, kwargs=kwargs)
            self.threads.append(thread)

    def start(self):
        """ to start all threads """
        for thread in self.threads:
            thread.start()

    def wait(self):
        """ to wait for all threads to end """
        for thread in self.threads:
            thread.join()

    def join(self):
        """ to start and wait for all threads to end """
        for thread in self.threads:
            thread.start()
        for thread in self.threads:
            thread.join()
