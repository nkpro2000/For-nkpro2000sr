#!/usr/bin/env python3

import tkinter

import morse

WPM = morse.WPM
FS = morse.FS


def info():
    print("Window :")
    print(" None")


def main(message, wpm=-1, fs=-1):
    wpm = WPM if wpm == -1 else wpm
    fs = FS if fs == -1 else fs
    code = morse.stringToMorse(message)
    flip_intervals = morse.morseToFlipIntervals(code, wpm, fs)
    window = Window(flip_intervals)
    window.mainloop()


class Window(tkinter.Tk):
    def __init__(self, flip_intervals):
        self.flip_intervals = flip_intervals
        self.end = len(flip_intervals)
        self.i = 0
        self.previous = False
        super().__init__()
        self.title("funny-morse")
        self.configure(bg="#000000")
        self.update()

    def flip(self):
        self.configure(bg="#000000" if self.previous else "#ffffff")
        self.previous = not self.previous
        self.i += 1
        self.update()

    def update(self):
        if self.i >= self.end:
            self.destroy()
        else:
            sleep = self.flip_intervals[self.i]
            self.after(int(sleep), self.flip)
