****************
Installing NumPy
****************

In most use cases the best way to install NumPy on your system is by using a
pre-built package for your operating system.  Please see
https://scipy.org/install.html for links to available options.

For instructions on building for source package, see
:doc:`building`. This information is useful mainly for advanced users.
