.. versionadded:: 1.6.0

.. automodule:: numpy.polynomial.hermite
   :no-members:
   :no-inherited-members:
   :no-special-members:
